package com.revature.food;

public abstract class food {

	public food() {
		super();

	}
	public abstract void consumeFood();

}
