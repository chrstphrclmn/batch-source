package com.revature.food;

//shows inheritance because Chinese food is a child class of food
public class ChineseFood extends food implements MustEatFood{
	
	//private variables to use getters and setters, which is abstraction
	private String foodOfTheDay = "Roasted Duck";
	private float price = 9.50f; 
	private int customerRating = 5;
	
	
	
	public ChineseFood() {
		super();

	}
	//overloaded constructor showing polymorphism
	public ChineseFood(int customerRating, float price) {
		this();
		this.customerRating = customerRating;
		this.price = price;
	}
// using equals() and hash code to compare objects
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerRating;
		result = prime * result + ((foodOfTheDay == null) ? 0 : foodOfTheDay.hashCode());
		result = prime * result + Float.floatToIntBits(price);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChineseFood other = (ChineseFood) obj;
		if (customerRating != other.customerRating)
			return false;
		if (foodOfTheDay == null) {
			if (other.foodOfTheDay != null)
				return false;
		} else if (!foodOfTheDay.equals(other.foodOfTheDay))
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		return true;
	}

	public String getFoodOfTheDay() {
		return foodOfTheDay;
	}

	public void setFoodOfTheDay(String foodOfTheDay) {
		this.foodOfTheDay = foodOfTheDay;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price; 
		try {
		if(price < 0) {
			throw new NegativePriceException(); //create new exception class
			
		}}  catch (NegativePriceException e) {
			
			System.out.println("cannot put negative number here");
			
		
		}
			
		
	
	}
	
	public int getCustomerRating() {
		return customerRating;
	}

	public void setCustomerRating(int customerRating) {
		this.customerRating = customerRating;
	}

	@Override
	public void consumeFood() {
		System.out.println("Use Chopsticks");
		//consume food method must be used because Chinese food implements interface
		giveBill(); 
		
		
	}
	public void giveBill() {
		System.out.println("Your total bill is " + price);
	}

}
