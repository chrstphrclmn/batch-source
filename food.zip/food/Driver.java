package com.revature.food;

public class Driver {

	public static void main(String[] args) {
		
		food f = new ChineseFood();
		
		ChineseFood c = new ChineseFood();
		AmericanFood a = new AmericanFood();
		ItalianFood i = new ItalianFood();
		
		c.consumeFood();
		a.consumeFood();
		i.consumeFood();
		
		f.consumeFood();
		
		// TODO Auto-generated method stub

	}

}
