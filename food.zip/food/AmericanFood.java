package com.revature.food;

public class AmericanFood extends food {
	
	public AmericanFood() {
		super();
	}


	@Override
	public void consumeFood() {
		System.out.println("Pick up food");
		
		
	}

}
