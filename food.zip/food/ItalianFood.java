package com.revature.food;

public class ItalianFood extends food {
	
	public ItalianFood() {
		super();
	}


	@Override
	public void consumeFood() {
		System.out.println("Pick up fork");
		// TODO Auto-generated method stub
		
	}

}
