package com.revature.food;

public interface MustEatFood {
	
	 void consumeFood();
	 
}
